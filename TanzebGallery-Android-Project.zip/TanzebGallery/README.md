# Tanzeb Gallery

Native Android Gallery starter app for the Tanzeb brand.

Features in v1:
- Reads device Photos and Videos through MediaStore
- 3-column gallery grid
- All / Photos / Videos / Favorites filters
- Search
- Full-screen photo viewer
- Video player
- Favorites
- Delete with Android confirmation on Android 11+
- Supplied Tanzeb image used as the launcher icon

Build:
1. Open this project in Android Studio, or push it to GitHub.
2. GitHub Actions can build `app-debug.apk` using the included workflow.
