package com.tanzeb.gallery;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Size;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.IOException;
import java.util.*;

public class MainActivity extends Activity {
    static final int PERM = 20;
    GridView grid;
    TextView count, empty;
    EditText search;
    ArrayList<MediaItem> all = new ArrayList<>();
    ArrayList<MediaItem> shown = new ArrayList<>();
    String filter = "all";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        grid=findViewById(R.id.grid);
        count=findViewById(R.id.count);
        empty=findViewById(R.id.empty);
        search=findViewById(R.id.search);

        findViewById(R.id.allBtn).setOnClickListener(v->{filter="all"; loadMedia();});
        findViewById(R.id.photoBtn).setOnClickListener(v->{filter="photo"; loadMedia();});
        findViewById(R.id.videoBtn).setOnClickListener(v->{filter="video"; loadMedia();});
        findViewById(R.id.favBtn).setOnClickListener(v->{filter="fav"; loadMedia();});

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ applySearch(s.toString()); }
            public void afterTextChanged(Editable e){}
        });

        requestMediaPermission();
    }

    void requestMediaPermission(){
        ArrayList<String> p=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=33){
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)!=PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.READ_MEDIA_IMAGES);
            if(checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO)!=PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else if(Build.VERSION.SDK_INT>=23 &&
                checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
            p.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if(!p.isEmpty()) requestPermissions(p.toArray(new String[0]),PERM);
        else loadMedia();
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==PERM) loadMedia();
    }

    void loadMedia(){
        all.clear();
        ContentResolver cr=getContentResolver();
        queryCollection(cr, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false);
        queryCollection(cr, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true);
        Collections.sort(all,(a,b)->Long.compare(b.date,a.date));
        applySearch(search.getText().toString());
    }

    void queryCollection(ContentResolver cr, Uri collection, boolean video){
        String[] proj={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED};
        try(Cursor c=cr.query(collection,proj,null,null,MediaStore.MediaColumns.DATE_ADDED+" DESC")){
            if(c==null)return;
            int id=c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
            int name=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
            int date=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED);
            while(c.moveToNext()){
                long row=c.getLong(id);
                Uri uri=ContentUris.withAppendedId(collection,row);
                all.add(new MediaItem(uri,c.getString(name),c.getLong(date),video));
            }
        }
    }

    void applySearch(String q){
        shown.clear();
        String s=q.toLowerCase(Locale.ROOT);
        for(MediaItem m:all){
            boolean typeOk=filter.equals("all") ||
                    (filter.equals("photo")&&!m.video) ||
                    (filter.equals("video")&&m.video) ||
                    (filter.equals("fav")&&Favorites.has(this,m.uri.toString()));
            if(typeOk && (s.isEmpty()||m.name.toLowerCase(Locale.ROOT).contains(s))) shown.add(m);
        }
        count.setText(String.valueOf(shown.size()));
        empty.setVisibility(shown.isEmpty()?View.VISIBLE:View.GONE);
        grid.setAdapter(new MediaAdapter(this,shown));
    }

    static class MediaItem{
        Uri uri; String name; long date; boolean video;
        MediaItem(Uri u,String n,long d,boolean v){uri=u;name=n;date=d;video=v;}
    }

    class MediaAdapter extends BaseAdapter{
        Context ctx; ArrayList<MediaItem> data;
        MediaAdapter(Context c,ArrayList<MediaItem> d){ctx=c;data=d;}
        public int getCount(){return data.size();}
        public Object getItem(int p){return data.get(p);}
        public long getItemId(int p){return p;}
        public View getView(int p,View convert,ViewGroup parent){
            ImageView iv=(ImageView)convert;
            if(iv==null){
                iv=new ImageView(ctx);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                int w=getResources().getDisplayMetrics().widthPixels/3;
                iv.setLayoutParams(new AbsListView.LayoutParams(w,w));
            }
            MediaItem m=data.get(p);
            try{
                Bitmap b;
                if(Build.VERSION.SDK_INT>=29){
                    b=getContentResolver().loadThumbnail(m.uri,new Size(400,400),null);
                }else{
                    b=m.video ? MediaStore.Video.Thumbnails.getThumbnail(
                            getContentResolver(),ContentUris.parseId(m.uri),
                            MediaStore.Video.Thumbnails.MINI_KIND,null)
                            : MediaStore.Images.Thumbnails.getThumbnail(
                            getContentResolver(),ContentUris.parseId(m.uri),
                            MediaStore.Images.Thumbnails.MINI_KIND,null);
                }
                iv.setImageBitmap(b);
            }catch(Exception e){iv.setImageResource(android.R.drawable.ic_menu_report_image);}
            iv.setOnClickListener(v->{
                Intent i=new Intent(MainActivity.this,ViewerActivity.class);
                i.setData(m.uri);
                i.putExtra("video",m.video);
                i.putExtra("name",m.name);
                startActivity(i);
            });
            return iv;
        }
    }
}

class Favorites{
    static final String KEY="favorites";
    static boolean has(Context c,String u){
        return c.getSharedPreferences("tanzeb",0).getStringSet(KEY,Collections.emptySet()).contains(u);
    }
    static void toggle(Context c,String u){
        android.content.SharedPreferences sp=c.getSharedPreferences("tanzeb",0);
        HashSet<String> s=new HashSet<>(sp.getStringSet(KEY,Collections.emptySet()));
        if(!s.add(u))s.remove(u);
        sp.edit().putStringSet(KEY,s).apply();
    }
}
