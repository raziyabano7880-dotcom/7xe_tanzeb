package com.tanzeb.gallery;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PERM=20, PICK_PRIVATE=30;
    GridView grid; TextView title,count,empty; EditText search;
    ArrayList<MediaItem> all=new ArrayList<>(), shown=new ArrayList<>();
    String filter="all", album="";

    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
        title=findViewById(R.id.title); count=findViewById(R.id.count); grid=findViewById(R.id.grid); empty=findViewById(R.id.empty); search=findViewById(R.id.search);
        findViewById(R.id.galleryTab).setOnClickListener(v->{filter="all";album="";title.setText("Tanzeb");loadMedia();});
        findViewById(R.id.photosTab).setOnClickListener(v->{filter="photo";album="";title.setText("Photos");loadMedia();});
        findViewById(R.id.videosTab).setOnClickListener(v->{filter="video";album="";title.setText("Videos");loadMedia();});
        findViewById(R.id.albumsTab).setOnClickListener(v->showAlbums());
        findViewById(R.id.privateTab).setOnClickListener(v->openPrivate());
        findViewById(R.id.favTab).setOnClickListener(v->{filter="fav";album="";title.setText("Favorites");loadMedia();});
        
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){apply();} public void afterTextChanged(Editable e){}});
        findViewById(R.id.menu).setOnClickListener(v->menu());
        requestPermission();
    }
    void requestPermission(){ArrayList<String> p=new ArrayList<>(); if(Build.VERSION.SDK_INT>=33){if(checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_MEDIA_IMAGES);if(checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_MEDIA_VIDEO);}else if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_EXTERNAL_STORAGE);if(p.isEmpty())loadMedia();else requestPermissions(p.toArray(new String[0]),PERM);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==PERM)loadMedia();}
    void loadMedia(){all.clear();ContentResolver cr=getContentResolver();query(cr,MediaStore.Images.Media.EXTERNAL_CONTENT_URI,false);query(cr,MediaStore.Video.Media.EXTERNAL_CONTENT_URI,true);Collections.sort(all,(a,b)->Long.compare(b.date,a.date));apply();}
    void query(ContentResolver cr,Uri col,boolean video){String[] pr={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.DATE_ADDED,MediaStore.MediaColumns.BUCKET_DISPLAY_NAME};try(Cursor c=cr.query(col,pr,null,null,MediaStore.MediaColumns.DATE_ADDED+" DESC")){if(c==null)return;while(c.moveToNext()){long id=c.getLong(0);Uri u=Uri.withAppendedPath(col,String.valueOf(id));String n=c.getString(1);long d=c.getLong(2);String folder=c.getString(3);all.add(new MediaItem(u,n,d,video,folder==null?"Other":folder));}}catch(Exception ignored){}}
    void apply(){shown.clear();String q=search.getText().toString().toLowerCase(Locale.ROOT);for(MediaItem m:all){boolean ok=filter.equals("all")||(filter.equals("photo")&&!m.video)||(filter.equals("video")&&m.video)||(filter.equals("fav")&&Favorites.has(this,m.uri.toString()));if(!album.isEmpty()&&!album.equals(m.folder))ok=false;if(ok&&(q.isEmpty()||m.name.toLowerCase(Locale.ROOT).contains(q)))shown.add(m);}count.setText(shown.size()+" items");empty.setVisibility(shown.isEmpty()?View.VISIBLE:View.GONE);grid.setAdapter(new MediaAdapter(shown));}
    void showAlbums(){HashMap<String,Integer> map=new HashMap<>();for(MediaItem m:all)map.put(m.folder,map.getOrDefault(m.folder,0)+1);ArrayList<String> names=new ArrayList<>(map.keySet());Collections.sort(names);if(names.isEmpty()){Toast.makeText(this,"No albums found",Toast.LENGTH_SHORT).show();return;}LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,8,24,8);for(String n:names){Button b=new Button(this);b.setText("📁 "+n+"   •   "+map.get(n));b.setAllCaps(false);b.setOnClickListener(v->{album=n;filter="all";title.setText(n);((Dialog)v.getTag()).dismiss();apply();});box.addView(b); }Dialog d=new AlertDialog.Builder(this).setTitle("Albums").setView(box).setNegativeButton("Close",null).create();for(int i=0;i<box.getChildCount();i++)box.getChildAt(i).setTag(d);d.show();}
    void openPrivate(){startActivity(new Intent(this,PrivateActivity.class));}
    void pickPrivate(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_PRIVATE);}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==PICK_PRIVATE&&c==RESULT_OK&&data!=null){int added=0;try{if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)added+=PrivateStore.copy(this,data.getClipData().getItemAt(i).getUri())?1:0;}else if(data.getData()!=null)added=PrivateStore.copy(this,data.getData())?1:0;}catch(Exception ignored){}Toast.makeText(this,added+" file(s) added to Private",Toast.LENGTH_SHORT).show();}}
    void menu(){String[] x={"Private Folder","Add to Private","App Info"};new AlertDialog.Builder(this).setTitle("Tanzeb").setItems(x,(d,w)->{if(w==0)openPrivate();else if(w==1)pickPrivate();else new AlertDialog.Builder(this).setTitle("Tanzeb Gallery V2").setMessage("Aesthetic Gallery • Albums • Private Folder • Favorites • Share\n\nPrivate files are stored inside the app.").setPositiveButton("OK",null).show();}).show();}

    class MediaAdapter extends BaseAdapter{ArrayList<MediaItem> data;MediaAdapter(ArrayList<MediaItem>d){data=d;}public int getCount(){return data.size();}public Object getItem(int p){return data.get(p);}public long getItemId(int p){return p;}public View getView(int p,View v,ViewGroup parent){ImageView iv=(ImageView)v;if(iv==null){iv=new ImageView(MainActivity.this);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);int w=getResources().getDisplayMetrics().widthPixels/3;iv.setLayoutParams(new AbsListView.LayoutParams(w,w));iv.setPadding(2,2,2,2);}MediaItem m=data.get(p);try{Bitmap b;if(Build.VERSION.SDK_INT>=29)b=getContentResolver().loadThumbnail(m.uri,new android.util.Size(500,500),null);else b=null;iv.setImageBitmap(b);}catch(Exception e){iv.setImageResource(android.R.drawable.ic_menu_report_image);}iv.setOnClickListener(x->{Intent i=new Intent(MainActivity.this,ViewerActivity.class);i.setData(m.uri);i.putExtra("video",m.video);i.putExtra("name",m.name);startActivity(i);});return iv;}}
    static class MediaItem{Uri uri;String name,folder;long date;boolean video;MediaItem(Uri u,String n,long d,boolean v,String f){uri=u;name=n;date=d;video=v;folder=f;}}
}
class Favorites{static final String KEY="favorites";static boolean has(Context c,String u){return c.getSharedPreferences("tanzeb",0).getStringSet(KEY,Collections.emptySet()).contains(u);}static void toggle(Context c,String u){android.content.SharedPreferences sp=c.getSharedPreferences("tanzeb",0);HashSet<String>s=new HashSet<>(sp.getStringSet(KEY,Collections.emptySet()));if(!s.add(u))s.remove(u);sp.edit().putStringSet(KEY,s).apply();}}
class PrivateStore{static File dir(Context c){File d=new File(c.getFilesDir(),"private");if(!d.exists())d.mkdirs();return d;}static boolean copy(Context c,Uri u){try{String name="IMG_"+System.currentTimeMillis()+".jpg";File out=new File(dir(c),name);InputStream in=c.getContentResolver().openInputStream(u);if(in==null)return false;FileOutputStream os=new FileOutputStream(out);byte[]b=new byte[8192];int n;while((n=in.read(b))>0)os.write(b,0,n);in.close();os.close();return true;}catch(Exception e){return false;}}}
