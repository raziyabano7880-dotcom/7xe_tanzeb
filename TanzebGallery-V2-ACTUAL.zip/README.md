# Tanzeb Gallery V2
Native Android gallery with aesthetic UI, albums, favorites, private app storage, search, photo/video browsing and sharing through Android's share sheet.

Note: the Private Folder stores copies inside the app sandbox. A real internet "share link" requires a backend/server; this version provides device share for gallery media.
