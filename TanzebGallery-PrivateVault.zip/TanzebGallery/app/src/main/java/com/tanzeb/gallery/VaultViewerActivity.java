package com.tanzeb.gallery;
import android.app.*;import android.graphics.Color;import android.net.Uri;import android.view.*;import android.widget.*;import java.io.File;
public class VaultViewerActivity extends Activity{
 public void onCreate(android.os.Bundle b){super.onCreate(b);String path=getIntent().getStringExtra("file");boolean video=getIntent().getBooleanExtra("video",false);FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);if(video){VideoView v=new VideoView(this);v.setVideoPath(path);v.setMediaController(new MediaController(this));root.addView(v,new FrameLayout.LayoutParams(-1,-1));v.start();}else{ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.FIT_CENTER);im.setImageURI(Uri.fromFile(new File(path)));root.addView(im,new FrameLayout.LayoutParams(-1,-1));}setContentView(root);}
 protected void onDestroy(){String p=getIntent().getStringExtra("file");if(p!=null)new File(p).delete();super.onDestroy();}
}
