package com.tanzeb.gallery;

import android.content.Context;
import android.util.Base64;
import java.io.*;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.SecretKeySpec;

final class VaultCrypto {
    private static final String PREF="vault_secure";
    private static final int ITER=150000;
    private static final SecureRandom RNG=new SecureRandom();
    private VaultCrypto(){}
    static boolean configured(Context c){return c.getSharedPreferences(PREF,0).contains("pw_wrap");}
    static String createVault(Context c,String password){try{
        byte[] master=rand(32); String recovery=String.format(Locale.US,"%03d-%03d-%03d-%03d",RNG.nextInt(1000),RNG.nextInt(1000),RNG.nextInt(1000),RNG.nextInt(1000));
        byte[] ps=rand(16),rs=rand(16); Wrapped pw=wrap(master,password,ps),rw=wrap(master,recovery,rs);
        c.getSharedPreferences(PREF,0).edit().putString("pw_salt",b64(ps)).putString("pw_iv",b64(pw.iv)).putString("pw_wrap",b64(pw.data)).putString("rec_salt",b64(rs)).putString("rec_iv",b64(rw.iv)).putString("rec_wrap",b64(rw.data)).apply();
        return recovery;
    }catch(Exception e){throw new RuntimeException(e);}}
    static byte[] unlock(Context c,String secret,boolean recovery){try{
        android.content.SharedPreferences p=c.getSharedPreferences(PREF,0);String pre=recovery?"rec_":"pw_";
        return decrypt(from(p.getString(pre+"wrap",null)),derive(secret,from(p.getString(pre+"salt",null))),from(p.getString(pre+"iv",null)));
    }catch(Exception e){return null;}}
    static void changePassword(Context c,byte[] master,String newPassword){try{
        byte[] salt=rand(16);Wrapped w=wrap(master,newPassword,salt);c.getSharedPreferences(PREF,0).edit().putString("pw_salt",b64(salt)).putString("pw_iv",b64(w.iv)).putString("pw_wrap",b64(w.data)).apply();
    }catch(Exception e){throw new RuntimeException(e);}}
    static File encryptFile(Context c,InputStream in,String name,byte[] master,boolean video)throws Exception{
        File dir=new File(c.getFilesDir(),"vault");if(!dir.exists())dir.mkdirs();File out=new File(dir,System.currentTimeMillis()+"_"+UUID.randomUUID()+".tvault");byte[] iv=rand(12);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(master,"AES"),new GCMParameterSpec(128,iv));
        try(FileOutputStream fos=new FileOutputStream(out);DataOutputStream dos=new DataOutputStream(fos)){
            dos.writeInt(iv.length);dos.write(iv);dos.writeBoolean(video);dos.writeUTF(name==null?"item":name);dos.flush();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){byte[] x=cipher.update(buf,0,n);if(x!=null)fos.write(x);}byte[] fin=cipher.doFinal();if(fin!=null)fos.write(fin);
        }return out;
    }
    static Decrypted decryptToCache(Context c,File enc,byte[] master)throws Exception{
        try(DataInputStream dis=new DataInputStream(new FileInputStream(enc))){int len=dis.readInt();byte[] iv=new byte[len];dis.readFully(iv);boolean video=dis.readBoolean();String name=dis.readUTF();File cache=new File(c.getCacheDir(),"vault_view_"+UUID.randomUUID());
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(master,"AES"),new GCMParameterSpec(128,iv));
            try(CipherInputStream cis=new CipherInputStream(dis,cipher);FileOutputStream fos=new FileOutputStream(cache)){byte[] buf=new byte[8192];int n;while((n=cis.read(buf))!=-1)fos.write(buf,0,n);}return new Decrypted(cache,video,name);
        }
    }
    static byte[] rand(int n){byte[] b=new byte[n];RNG.nextBytes(b);return b;}static String b64(byte[] b){return Base64.encodeToString(b,Base64.NO_WRAP);}static byte[] from(String s){return Base64.decode(s,Base64.NO_WRAP);}
    static byte[] derive(String s,byte[] salt)throws Exception{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(new PBEKeySpec(s.toCharArray(),salt,ITER,256)).getEncoded();}
    static Wrapped wrap(byte[] plain,String secret,byte[] salt)throws Exception{byte[] iv=rand(12);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(derive(secret,salt),"AES"),new GCMParameterSpec(128,iv));return new Wrapped(iv,c.doFinal(plain));}
    static byte[] decrypt(byte[] data,byte[] key,byte[] iv)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,iv));return c.doFinal(data);}
    static class Wrapped{byte[] iv,data;Wrapped(byte[] i,byte[] d){iv=i;data=d;}}static class Decrypted{File file;boolean video;String name;Decrypted(File f,boolean v,String n){file=f;video=v;name=n;}}
}
